package com.example.moneyspend.models;

import java.io.Serializable;

/**
 * The type User.
 */
public class User implements Serializable {

    private int id;
    private String name;
    private String email;
    private String password;
    private String phoneNumber;
    private double totalBalance;

    /**
     * Instantiates a new User.
     */
    public User() {
    }

    /**
     * Instantiates a new User.
     *
     * @param id           the id
     * @param name         the name
     * @param email        the email
     * @param password     the password
     * @param phoneNumber  the phone number
     * @param totalBalance the total balance
     */
    public User(int id, String name, String email, String password, String phoneNumber, long totalBalance) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.totalBalance = totalBalance;
    }

    /**
     * Instantiates a new User.
     *
     * @param name         the name
     * @param email        the email
     * @param password     the password
     * @param phoneNumber  the phone number
     * @param totalBalance the total balance
     */
    public User(String name, String email, String password, String phoneNumber, long totalBalance) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.totalBalance = totalBalance;
    }

    /**
     * Gets id.
     *
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets id.
     *
     * @param id the id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets name.
     *
     * @param name the name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets email.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets email.
     *
     * @param email the email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets password.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets password.
     *
     * @param password the password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets phone number.
     *
     * @return the phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets phone number.
     *
     * @param phoneNumber the phone number
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Gets total balance.
     *
     * @return the total balance
     */
    public double getTotalBalance() {
        return totalBalance;
    }

    /**
     * Sets total balance.
     *
     * @param totalBalance the total balance
     */
    public void setTotalBalance(double totalBalance) {
        this.totalBalance = totalBalance;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", totalBalance=" + totalBalance +
                '}';
    }
}
