package com.example.moneyspend.models;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * The type Transaction.
 */
public class Transaction implements Serializable {

    private int transactionID;
    private int transactionType;
    private double amount;
    private String details;
    private int userID;
    private String transactionTime;

    /**
     * Instantiates a new Transaction.
     */
    public Transaction() {
    }

    /**
     * Instantiates a new Transaction.
     *
     * @param transactionID   the transaction id
     * @param transactionType the transaction type
     * @param amount          the amount
     * @param details         the details
     * @param userID          the user id
     * @param transactionTime the transaction time
     */
    public Transaction(int transactionID, int transactionType, double amount, String details, int userID, String transactionTime) {
        this.transactionID = transactionID;
        this.transactionType = transactionType;
        this.amount = amount;
        this.details = details;
        this.userID = userID;
        this.transactionTime = transactionTime;
    }

    /**
     * Gets transaction id.
     *
     * @return the transaction id
     */
    public int getTransactionID() {
        return transactionID;
    }

    /**
     * Sets transaction id.
     *
     * @param transactionID the transaction id
     */
    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }

    /**
     * Gets transaction type.
     *
     * @return the transaction type
     */
    public int getTransactionType() {
        return transactionType;
    }

    /**
     * Sets transaction type.
     *
     * @param transactionType the transaction type
     */
    public void setTransactionType(int transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * Gets amount.
     *
     * @return the amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Sets amount.
     *
     * @param amount the amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Gets details.
     *
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Sets details.
     *
     * @param details the details
     */
    public void setDetails(String details) {
        this.details = details;
    }

    /**
     * Gets user id.
     *
     * @return the user id
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets user id.
     *
     * @param userID the user id
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Gets transaction time.
     *
     * @return the transaction time
     */
    public String getTransactionTime() {
        return transactionTime;
    }

    /**
     * Sets transaction time.
     *
     * @param transactionTime the transaction time
     */
    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "transactionID=" + transactionID +
                ", transactionType=" + transactionType +
                ", amount=" + amount +
                ", details='" + details + '\'' +
                ", userID=" + userID +
                ", transactionTime=" + transactionTime +
                '}';
    }
}
