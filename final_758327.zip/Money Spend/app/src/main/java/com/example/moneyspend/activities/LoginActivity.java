package com.example.moneyspend.activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.moneyspend.R;
import com.example.moneyspend.models.User;
import com.example.moneyspend.utils.DatabaseHelper;

import java.security.SecureRandom;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import es.dmoral.toasty.Toasty;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    /**
     * The constant VALID_EMAIL_ADDRESS_REGEX.
     */
    /* Regex used for validating email address*/
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    static final String ALPHA_NUMERIC = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    /*Constants Used*/
    static SecureRandom rnd = new SecureRandom(); // random number generation object for generating code
    private EditText emailEditText; // field to enter email
    private EditText passwordEditText;  //field to enter password
    private TextView forgotPasswordTextView; // forgot password clickable text
    private Button loginButton; // login button to process login
    private TextView registerTextView; // registration clickable text
    private DatabaseHelper databaseHelper; // database object
    boolean doubleBackToExitPressedOnce = false;
    private String resetCode; // the reset code is forgot password is clicked

    /**
     * This method is caleed when the activity is cleared
     *
     * @param savedInstanceState the savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeWidgets();
    }

    /**
     * Validate email boolean.
     *
     * @param emailStr the email str
     * @return the boolean
     */
    public static boolean validateEmail(CharSequence emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.find();
    }

    /**
     * This method initializes the widgets shown on screen
     */
    @SuppressLint("ClickableViewAccessibility")
    private void initializeWidgets() {

        databaseHelper = new DatabaseHelper(getApplicationContext()); // initialize the database object

        emailEditText = findViewById(R.id.emailEditText);

        passwordEditText = findViewById(R.id.passwordEditText);

        forgotPasswordTextView = findViewById(R.id.forgotPasswordTextView);
        forgotPasswordTextView.setOnClickListener(this);
        //setting animation on button
        forgotPasswordTextView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Animation click = AnimationUtils.loadAnimation(LoginActivity.this.getApplicationContext(),
                        R.anim.click);
                forgotPasswordTextView.startAnimation(click);
                return false;
            }
        });

        loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(this);
        // login button animation
        loginButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Animation click = AnimationUtils.loadAnimation(LoginActivity.this.getApplicationContext(),
                        R.anim.click);
                loginButton.startAnimation(click);
                return false;
            }
        });

        registerTextView = findViewById(R.id.registerTextView);
        registerTextView.setOnClickListener(this);
        registerTextView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Animation click = AnimationUtils.loadAnimation(LoginActivity.this.getApplicationContext(),
                        R.anim.click);
                registerTextView.startAnimation(click);
                return false;
            }
        });
    }

    /**
     * This method is called when any widget is clicked
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        // if login button is pressed
        if (v == loginButton) {
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password)) {
                if (databaseHelper.checkUser(email, password)) {
                    Toasty.success(getApplicationContext(), "Login Successful!", Toast.LENGTH_SHORT, true).show();
                    emailEditText.setText("");
                    passwordEditText.setText("");
                    Intent i = new Intent(LoginActivity.this, DashboardActivity.class);
                    i.putExtra("userObject", databaseHelper.getUser(email));
                    startActivity(i);
                    finish();
                } else {
                    emailEditText.setText("");
                    passwordEditText.setText("");
                    Toasty.error(getApplicationContext(), "User doesn't exist", Toast.LENGTH_SHORT, true).show();
                }
            } else
                Toasty.error(getApplicationContext(), "Please fill both the fields to login", Toast.LENGTH_SHORT, true).show();
        }

        // if forgot password text is clicked
        if (v == forgotPasswordTextView) {
            AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
            builder.setTitle("Reset Password");

            LayoutInflater inflater = (LayoutInflater) LoginActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            @SuppressLint("InflateParams") View alertDialogView = inflater.inflate(R.layout.input_email, null);
            builder.setView(alertDialogView);
            builder.setIcon(R.mipmap.ic_launcher);
            builder.setCancelable(false);

            final EditText inputEditText = alertDialogView.findViewById(R.id.inputEditText);

            builder.setView(alertDialogView);

            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String dialogEmailAddress = inputEditText.getText().toString();
                    dialog.cancel();
                    if (validateEmail(dialogEmailAddress)) {
                        if (databaseHelper.getUser(dialogEmailAddress) != null) {
                            Toasty.success(LoginActivity.this, "Password reset email sent to: " + dialogEmailAddress
                                    , Toast.LENGTH_SHORT, true).show();

                            Toasty.info(getApplicationContext(), " Email Sent.", Toasty.LENGTH_SHORT,true).show();
                            confirmCode(dialogEmailAddress);
                            new SendEmailTask(dialogEmailAddress).execute();

                        } else {

                        }
                    } else
                        Toasty.error(LoginActivity.this, "Incorrect email", Toast.LENGTH_SHORT, true).show();

                }
            });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            builder.show();

        }

        // if register text is clicked
        if (v == registerTextView) {
            startActivity(new Intent(LoginActivity.this, SignupActivity.class));
            finish();
        }
    }

    /**
     * Open popup for lettting the user enter the email for which he/she wants to receive password
     * @param emailAdd the Email Address
     */
    private void confirmCode(final String emailAdd) {
        // make a popup
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        builder.setTitle("Enter Code");

        LayoutInflater inflater = (LayoutInflater) LoginActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert inflater != null;
        @SuppressLint("InflateParams") View alertDialogView = inflater.inflate(R.layout.input_code, null);
        builder.setView(alertDialogView);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setCancelable(false);

        final EditText codeEditText = alertDialogView.findViewById(R.id.inputEditText);

        builder.setView(alertDialogView);

        // set ok button to send verification code
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String code = codeEditText.getText().toString(); // get the code which is entered

                if (code.equals(resetCode)) { // check if the code that is entered is same as the code that was sent to the email address
                    databaseHelper = new DatabaseHelper(getApplicationContext());

                    User user = databaseHelper.getUser(emailAdd); // get user from database so that new password can be updated
                    if (user != null) {
                        user.setPassword(resetCode);

                        databaseHelper.updateUser(user); // update the user
                        Toasty.success(getApplicationContext(), "Reset code is now your current password", Toasty.LENGTH_SHORT, true).show();
                        dialog.cancel();
                    } else {
                        Toasty.error(getApplicationContext(), "Error occurred! Please try again", Toasty.LENGTH_SHORT,true).show();
                        dialog.cancel();
                    }
                } else {
                    Toasty.error(getApplicationContext(), "Invalid code", Toasty.LENGTH_SHORT,true).show();
                }

            }
        });
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toasty.info(getApplicationContext(), "Reset Failed", Toast.LENGTH_LONG, true).show();
                dialog.cancel();
            }
        });

        builder.show();
    }

    /**
     * If back button is pressed
     */
    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            finish();
            System.exit(0);
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toasty.warning(this, "Click BACK twice to exit", Toast.LENGTH_SHORT, true).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }

    /**
     * Generate random string
     * @return a random string of size 6 letters
     */
    private String randomString() {
        StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; i++)
            sb.append(ALPHA_NUMERIC.charAt(rnd.nextInt(ALPHA_NUMERIC.length())));
        return sb.toString();
    }

    /**
     * This class handles the sending of reset email to the entered email address
     */
    public class SendEmailTask extends AsyncTask<String, Integer, Integer> {
        private String emailAddress; // email address on which email has to be sent

        // the constructor
        SendEmailTask(String dialogEmailAddress) {
            emailAddress = dialogEmailAddress;
        }

        /**
         *
         * @param strings the Strings
         * @return integer
         */
        @Override
        protected Integer doInBackground(String... strings) {

            // setting the mail properties
            /**
             * byteitsolutions.co is my server which I have used for you to send email.
             * you can use your own email as well for this purpose but you have to configure it so
             * that there is no 2 step verification involved, then you just have to write your email address and password below
             */
            final String emailForTheServer = "password.saver.app@byteitsolutions.co";
            final String passwordForTheServer = "passwordsaver123!@#";

            Properties props = new Properties();
            // the below properties are to be inserted as it is, these are server configurations, I won't go into their depth because
            // they are very lengthy to discuss
            props.put("mail.smtp.host", "mail.byteitsolutions.co"); // my server host address
            props.put("mail.smtp.socketFactory.port", "143");
            props.put("mail.smtp.socketFactory.class",
                    "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "587");

            // start a session to login into the email from which we are going to send the email
            Session session = Session.getDefaultInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(emailForTheServer, passwordForTheServer);
                        }
                    });

            try {

                // create a message
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(emailForTheServer)); // set the sender email
                message.setRecipients(Message.RecipientType.TO, // set the recipient
                        InternetAddress.parse(emailAddress));
                message.setSubject("Password Reset Email"); // set the subject
                resetCode = randomString();
                // set the body
                message.setText("Dear user, Your reset code is: " + resetCode + "\n Valid for small time, make sure you don't quit the app" +
                        ".\n\n\nRegards,\nPassword Saver Application");

                Transport.send(message); // send email

            } catch (MessagingException e) {
                throw new RuntimeException(e); // throw any exception if any
            }
            return 1;
        }
    }

}
