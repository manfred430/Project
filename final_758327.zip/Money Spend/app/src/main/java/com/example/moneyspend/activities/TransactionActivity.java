package com.example.moneyspend.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.moneyspend.R;
import com.example.moneyspend.models.Transaction;
import com.example.moneyspend.models.User;
import com.example.moneyspend.utils.DatabaseHelper;

import es.dmoral.toasty.Toasty;

/**
 * The type Transaction activity.
 */
public class TransactionActivity extends AppCompatActivity implements View.OnClickListener {

    private static int TYPE;
    private EditText amountEditText;
    private EditText detailsEditText;
    private EditText dateEditText;
    private Button saveButton;
    private ImageView backButton;

    private DatabaseHelper databaseHelper;
    private static User currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);
        currentUser = (User) getIntent().getSerializableExtra("userObject");

        TYPE = getIntent().getIntExtra("TYPE", -1);
        initializeWidgets();

    }

    private void initializeWidgets() {
        amountEditText = findViewById(R.id.amountEditText);
        detailsEditText = findViewById(R.id.detailsEditText);
        dateEditText = findViewById(R.id.dateEditText);
        saveButton = findViewById(R.id.saveButton);
        backButton = findViewById(R.id.backButton);
        saveButton.setOnClickListener(this);
        backButton.setOnClickListener(this);

        databaseHelper = new DatabaseHelper(getApplicationContext());
    }

    @Override
    public void onClick(View v) {
        if (v == backButton) {
            onBackPressed();
        }
        if (v == saveButton) {
            String amountEntered = amountEditText.getText().toString().trim();
            String details = detailsEditText.getText().toString();
            String date = dateEditText.getText().toString();

            if (!TextUtils.isEmpty(amountEntered) && !TextUtils.isEmpty(details) && !TextUtils.isEmpty(date)) {
                double amount;
                try {
                    amount = Double.parseDouble(amountEntered);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Toasty.error(getApplicationContext(), "Amount must be a number", Toasty.LENGTH_SHORT, true).show();
                    return;
                }
                Transaction transaction = new Transaction();
                transaction.setAmount(amount);
                transaction.setUserID(currentUser.getId());
                transaction.setTransactionTime(date);
                transaction.setDetails(details);
                if (TYPE == 0) {
                    currentUser.setTotalBalance(currentUser.getTotalBalance() + amount);
                    transaction.setTransactionType(0);
                } else if (TYPE == 1) {
                    currentUser.setTotalBalance(currentUser.getTotalBalance() - amount);
                    transaction.setTransactionType(1);
                } else {
                    Toasty.error(this, "ERROR", Toast.LENGTH_SHORT, true).show();
                    Intent i = new Intent(TransactionActivity.this, DashboardActivity.class);
                    i.putExtra("userObject", currentUser);
                    startActivity(i);
                    finish();
                }
                databaseHelper.addTransaction(transaction);

                Toasty.success(getApplicationContext(), "Transaction Added", Toast.LENGTH_SHORT, true).show();
                Intent i = new Intent(TransactionActivity.this, DashboardActivity.class);
                databaseHelper.updateUser(currentUser);
                i.putExtra("userObject", currentUser);
                startActivity(i);
                finish();
            } else {
                Toasty.error(getApplicationContext(), "Please fill all the fields", Toasty.LENGTH_SHORT, true).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(TransactionActivity.this, DashboardActivity.class);
        i.putExtra("userObject", currentUser);
        startActivity(i);
        finish();
    }
}
