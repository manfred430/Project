package com.example.moneyspend.activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.moneyspend.R;
import com.example.moneyspend.models.Transaction;
import com.example.moneyspend.models.User;
import com.example.moneyspend.utils.DatabaseHelper;
import com.example.moneyspend.utils.MyRecyclerViewAdapter;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity implements View.OnClickListener, MyRecyclerViewAdapter.ItemClickListener {

    private static User currentUser; // current user who is logged in
    private static ArrayList<Transaction> transactionArrayList; // the list of transactions done by current user

    private Button depositButton; // deposit button if transaction is of deposit type
    private Button spendButton; // spend button if transaction is of spend type
    private MyRecyclerViewAdapter adapter; // the adapter

    private DatabaseHelper databaseHelper; // database operations object

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        currentUser = (User) getIntent().getSerializableExtra("userObject"); // set the current user

        initializeWidgets();
    }

    /**
     * Initialize the widgets present on the screen
     */
    @SuppressLint("SetTextI18n")
    private void initializeWidgets() {
        TextView nameTextView = findViewById(R.id.nameTextView);
        TextView emailTextView = findViewById(R.id.emailTextView);
        TextView phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        TextView leftTextView = findViewById(R.id.leftTextView);

        nameTextView.setText("Name: " + currentUser.getName()); // display the name of current user
        emailTextView.setText("Email: " + currentUser.getEmail()); // display the email of current user
        phoneNumberTextView.setText("Phone #: " + currentUser.getPhoneNumber()); // display the phone number of current user
        leftTextView.setText("Balance: £" + currentUser.getTotalBalance()); // display the balance of current user

        databaseHelper = new DatabaseHelper(getApplicationContext()); // initialize database helper class
        transactionArrayList = databaseHelper.getAllTransactions(); // initialize the list of transactions

        ArrayList<Transaction> newArray = new ArrayList<>();

        // filter the transactions
        for (int i = 0; i < transactionArrayList.size(); i++) {
            if (transactionArrayList.get(i).getUserID() == currentUser.getId())
                newArray.add(transactionArrayList.get(i));
        }

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.passwordRecycleView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, newArray);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

        depositButton = findViewById(R.id.saveButton);
        spendButton = findViewById(R.id.spendButton);

        depositButton.setOnClickListener(this);
        spendButton.setOnClickListener(this);
    }

    /**
     * This method is called whenever the physical back button is called
     */
    @Override
    public void onBackPressed() {
        finish();
        startActivity(new Intent(this, LoginActivity.class));

    }

    /**
     * this method is called whenever any object is clicked on the screen
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        // if deposit button is pressed
        if (v == depositButton) {
            Intent intent = new Intent(this, TransactionActivity.class);
            intent.putExtra("TYPE", 0);
            intent.putExtra("userObject", currentUser);
            startActivity(intent);
            finish();
        }
        //if spend button is pressed
        if (v == spendButton) {
            Intent intent = new Intent(this, TransactionActivity.class);
            intent.putExtra("TYPE", 1);
            intent.putExtra("userObject", currentUser);
            startActivity(intent);
            finish();
        }
    }

    /**
     * if any specific transaction is clicked on the list
     *
     * @param view     the view
     * @param position the position
     */
    @Override
    public void onItemClick(View view, final int position) {
        // open a popup for further processing on list item
        AlertDialog alertDialog = new AlertDialog.Builder(DashboardActivity.this).create();
        alertDialog.setTitle("Transaction Operations");
        alertDialog.setIcon(R.mipmap.ic_launcher);
        alertDialog.setMessage("Do you want to delete or update the transaction having ID: "
                + transactionArrayList.get(position).getTransactionID());
        // set the delete transaction button
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "DELETE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        databaseHelper.deleteTransaction(transactionArrayList.get(position));
                        transactionArrayList.remove(position);
                        adapter.notifyDataSetChanged();
                    }
                });
        // set the edit transaction button
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "EDIT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        // set the cancel button
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }
}
